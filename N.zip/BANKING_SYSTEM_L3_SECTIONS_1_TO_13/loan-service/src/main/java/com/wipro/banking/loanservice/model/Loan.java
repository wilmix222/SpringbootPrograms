package com.wipro.banking.loanservice.model;
import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;


@Entity
@Table(name="LOANS")


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class Loan
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public Long id;
    private Long customerId;
    private java.math.BigDecimal principal;
    private Double interestRate=10.5;
    private Integer tenureMonths=12;
    private java.math.BigDecimal emi;
    private String status="APPLIED";
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}

}
