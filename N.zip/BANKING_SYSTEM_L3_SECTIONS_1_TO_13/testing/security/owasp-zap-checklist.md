# OWASP ZAP Security Checklist

- Scan auth endpoints.
- Scan customer/account/transaction APIs.
- Check missing security headers.
- Check injection and sensitive data exposure findings.
