package com.wipro.banking.authservice.model;
import javax.persistence.*; import javax.validation.constraints.NotBlank;
@Entity
@Table(name="APP_USERS", uniqueConstraints=@UniqueConstraint(columnNames="username"))
public class AppUser
{
 @Id

 @GeneratedValue(strategy=GenerationType.IDENTITY)
 private Long id;
 @NotBlank
 private String username;
 @NotBlank
 private String passwordHash;
 @Enumerated(EnumType.STRING)
 private Role role=Role.CUSTOMER;
 private boolean active=true;
 public Long getId(){return id;}

 public void setId(Long id){this.id=id;}
 public String getUsername(){return username;}
 public void setUsername(String username)
 {this.username=username;}
 public String getPasswordHash(){return passwordHash;}
 public void setPasswordHash(String passwordHash)
 {this.passwordHash=passwordHash;}
 public Role getRole(){return role;}
 public void setRole(Role role){this.role=role;}
 public boolean isActive(){return active;}
 public void setActive(boolean active){this.active=active;}
}
