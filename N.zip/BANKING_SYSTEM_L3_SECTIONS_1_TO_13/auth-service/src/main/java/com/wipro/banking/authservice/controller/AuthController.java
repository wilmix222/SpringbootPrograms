package com.wipro.banking.authservice.controller;
import com.wipro.banking.authservice.dto.*;


import com.wipro.banking.authservice.service.AuthServiceImpl;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController
@RequestMapping("/api/v1/auth")
public class AuthController{
    private final AuthServiceImpl service;
    public AuthController(AuthServiceImpl service)
    {this.service=service;} @PostMapping("/register")
    public AuthResponse register(@RequestBody RegisterRequest r)
    {return service.register(r);}
    @PostMapping("/login")
    public AuthResponse login(@RequestBody LoginRequest r)
    {return service.login(r);}
    @GetMapping("/validate")
    public Map<String,Object> validate(@RequestParam String token)
    { Map<String,Object> m=new HashMap<>();
        m.put("valid",service.validateToken(token)); return m;


    }


}
