package com.wipro.banking.authservice.model;
/*
public enum Role
{
    CUSTOMER, BANK_STAFF, ADMIN, AUDITOR

}
*/

public enum Role {

    ADMIN,
    CUSTOMER,
    AUDITOR,
    MANAGER

}