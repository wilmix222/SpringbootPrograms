package com.wipro.banking.authservice.exception;
import org.springframework.http.ResponseEntity; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestControllerAdvice public class GlobalExceptionHandler {
 @ExceptionHandler(IllegalArgumentException.class) public ResponseEntity<Map<String,String>> bad(IllegalArgumentException ex) { Map<String,String> body=new HashMap<>(); body.put("error", ex.getMessage()); return ResponseEntity.badRequest().body(body); }
}
