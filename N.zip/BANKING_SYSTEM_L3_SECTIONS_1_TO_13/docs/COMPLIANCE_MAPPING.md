# Compliance Mapping
| Area | Requirement | Project Evidence |
|---|---|---|
| GDPR | Data privacy | Minimal response data and retention policy |
| PCI-DSS | Card handling | AES-256 utility and masking utility |
| Banking operations | Sensitive action traceability | Audit service |
| Security | Password protection | BCrypt hashing |
| Security | Access control | RBAC roles and matrix |
| Security | Session control | Session timeout property |
