# Security Test Cases

- Register user stores BCrypt hash.
- Login fails with wrong password.
- AES encryption does not return plain text.
- Audit log defaults to success status.
