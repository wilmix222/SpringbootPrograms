# Integration Design

Integration-service acts as a controlled boundary for simulated external integrations for payment, KYC, AML, and credit scoring workflows.
