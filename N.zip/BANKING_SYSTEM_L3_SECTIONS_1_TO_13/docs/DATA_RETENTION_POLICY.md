# Data Retention Policy

Financial records and audit records should be retained according to regulatory needs. Deletion should be controlled, audited, and preferably archived instead of hard deleted.
