# 9. Integrations

Integration service provides simulated API boundaries for payment gateway, KYC/AML, and credit scoring integrations. Providers documented include NPCI/UPI/IMPS/NEFT/RTGS, SWIFT, Stripe/Razorpay, Digilocker/Onfido/Jumio, World-Check/Dow Jones, and CIBIL/Experian.
