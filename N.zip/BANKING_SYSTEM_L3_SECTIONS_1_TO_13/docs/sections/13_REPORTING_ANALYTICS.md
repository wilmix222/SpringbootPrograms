# 13. Reporting & Analytics

Reporting service provides report snapshot API and documentation for transaction trends, loan performance, customer segmentation, compliance reports, scheduled exports, and fraud alert reporting.
