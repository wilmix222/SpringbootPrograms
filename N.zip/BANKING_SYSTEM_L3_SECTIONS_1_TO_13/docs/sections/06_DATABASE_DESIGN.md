# 6. Database Design

Each service uses H2 for assignment execution. Entities include customers, accounts, transactions, loans, cards, notification logs, audit logs, integration requests, and report snapshots.
