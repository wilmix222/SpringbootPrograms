# 8. Security & Compliance

Includes BCrypt password hashing, AES-256 utility, RBAC documentation, session timeout, TLS notes, data retention policy, GDPR/PCI-DSS/banking compliance mapping, and audit logs for sensitive actions.
