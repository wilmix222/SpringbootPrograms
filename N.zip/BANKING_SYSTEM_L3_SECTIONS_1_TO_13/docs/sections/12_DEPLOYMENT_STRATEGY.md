# 12. Deployment Strategy

Includes Dockerfile per service, docker-compose, Kubernetes YAML, Jenkinsfile, GitHub Actions workflow, monitoring notes for Prometheus/Grafana, and ELK logging notes.
