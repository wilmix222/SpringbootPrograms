# 2. User Roles & Access Control

Roles: CUSTOMER, BANK_STAFF, ADMIN, AUDITOR. RBAC is documented in `RBAC_MATRIX.md`. Sensitive actions are designed to create audit logs.
