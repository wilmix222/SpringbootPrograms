# 5. Backend Services

Implemented backend services: Authentication, Customer, Account, Transaction, Loan, Card, Notification, Audit, Integration, and Reporting services.
