# 3. System Architecture

Architecture type: Microservices. Layers include presentation, service, data, and integration layers. Microservices are auth, customer, account, transaction, loan, card, notification, audit, integration, and reporting.
