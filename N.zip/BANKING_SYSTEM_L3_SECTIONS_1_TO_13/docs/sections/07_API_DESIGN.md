# 7. API Design

REST API style is used with `/api/v1/...` endpoints. Examples are included in the Postman collection.
