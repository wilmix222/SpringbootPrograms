# 4. Frontend Design

The assignment documentation maps web app dashboards for staff/admin and mobile workflows for customers. This project focuses on backend REST APIs and provides Postman collection for validation.
