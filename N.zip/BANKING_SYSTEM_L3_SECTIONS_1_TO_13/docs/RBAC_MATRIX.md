# RBAC Matrix
| Operation | CUSTOMER | BANK_STAFF | ADMIN | AUDITOR |
|---|---:|---:|---:|---:|
| Login | Yes | Yes | Yes | Yes |
| Create customer | No | Yes | Yes | No |
| Update KYC | No | Yes | Yes | No |
| View account | Own | Yes | Yes | Read-only |
| Fund transfer | Own | Yes | Yes | No |
| Loan approval | No | Yes | Yes | No |
| Audit logs | No | No | Yes | Yes |
| Reports | No | Yes | Yes | Yes |
