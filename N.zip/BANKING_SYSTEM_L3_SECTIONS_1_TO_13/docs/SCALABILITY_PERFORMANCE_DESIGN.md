# Scalability and Performance Design

Use stateless services, Kubernetes replicas, Redis caching for account balances/session data, database indexing for account number and customer ID, and load balancing through NGINX/HAProxy or cloud ingress.
