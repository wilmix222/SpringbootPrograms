# Reporting and Analytics Design

Reporting service stores snapshots for transaction volume, loan status, customer segmentation, compliance reports, scheduled regulator exports, and fraud alert summaries.
