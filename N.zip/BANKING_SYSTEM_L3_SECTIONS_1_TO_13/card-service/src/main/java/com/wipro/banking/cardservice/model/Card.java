package com.wipro.banking.cardservice.model;
import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name="CARDS")

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class Card{ @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
public Long id; private Long customerId; private String accountNumber;
private String cardType="DEBIT";
private java.math.BigDecimal limitAmount=java.math.BigDecimal.ZERO;
private String status="ACTIVE";

public Long getId(){return id;}
    public void setId(Long id){this.id=id;}


}
