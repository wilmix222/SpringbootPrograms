package com.wipro.banking.transactionservice.service;


import com.wipro.banking.transactionservice.model.TransactionRecord;
import com.wipro.banking.transactionservice.repository.TransactionRecordRepository;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class TransactionService {

    private final TransactionRecordRepository repo;

    public TransactionService(TransactionRecordRepository repo) {
        this.repo = repo;
    }

    public TransactionRecord transfer(TransactionRecord obj) {

        RestTemplate restTemplate = new RestTemplate();

        String fromAccount = obj.getSourceAccount();
        String toAccount = obj.getDestinationAccount();

        String amount = obj.getAmount().toString();

        // Debit source account
        restTemplate.postForObject(
                "http://localhost:8093/api/v1/accounts/"
                        + fromAccount
                        + "/debit?amount="
                        + amount,
                null,
                Object.class);

        // Credit destination account
        restTemplate.postForObject(
                "http://localhost:8093/api/v1/accounts/"
                        + toAccount
                        + "/credit?amount="
                        + amount,
                null,
                Object.class);

        // Save transaction
        return repo.save(obj);
    }
}