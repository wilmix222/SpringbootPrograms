package com.wipro.banking.transactionservice.repository;
import com.wipro.banking.transactionservice.model.TransactionRecord;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TransactionRecordRepository extends JpaRepository<TransactionRecord,Long>

{}
