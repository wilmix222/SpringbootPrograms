package com.wipro.banking.transactionservice.model;


import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "TRANSACTIONS")
public class TransactionRecord {

   @Id
    @GeneratedValue(strategy =GenerationType.IDENTITY)
    private Long id;

    private String sourceAccount;

    private String destinationAccount;

    private BigDecimal amount;

    private String transactionType = "IMPS";

    private String status = "SUCCESS";

    private LocalDateTime transactionTime = LocalDateTime.now();

    public TransactionRecord() {
    }

   public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
   }

    public String getSourceAccount() {
        return sourceAccount;
    }

    public void setSourceAccount(String sourceAccount) {
       this.sourceAccount = sourceAccount;
    }

    public String getDestinationAccount() {
        return destinationAccount;
    }

    public void setDestinationAccount(String destinationAccount) {
       this.destinationAccount = destinationAccount;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAccount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getTransactionType() {
       return transactionType;
   }

    public void setTransactionType(String transactionType) {
       this.transactionType = transactionType;
    }

    public String getStatus() {
        return status;
   }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getTransactionTime() {
       return transactionTime;
    }

   public void setTransactionTime(LocalDateTime transactionTime) {
       this.transactionTime = transactionTime;
    }

    private String approvalStatus = "PENDING";

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }
}