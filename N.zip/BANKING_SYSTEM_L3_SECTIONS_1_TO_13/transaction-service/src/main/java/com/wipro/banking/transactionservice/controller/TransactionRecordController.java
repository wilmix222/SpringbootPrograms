package com.wipro.banking.transactionservice.controller;


import com.wipro.banking.transactionservice.model.TransactionRecord;
import com.wipro.banking.transactionservice.repository.TransactionRecordRepository;
import com.wipro.banking.transactionservice.service.TransactionService;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/transactions")
@CrossOrigin(origins = "http://localhost:4200")
public class TransactionRecordController {

    private final TransactionService service;
    private final TransactionRecordRepository repo;


    public TransactionRecordController(
            TransactionService service,
            TransactionRecordRepository repo) {

        this.service = service;
        this.repo = repo;
    }

    @PostMapping
    public TransactionRecord create(
            @RequestBody TransactionRecord obj) {

        return service.transfer(obj);
    }

    @GetMapping
    public List<TransactionRecord> all() {

        return repo.findAll();
    }

    @GetMapping("/{id}")
    public TransactionRecord get(@PathVariable Long id) {

        return repo.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "TransactionRecord not found: " + id));
    }

    @PatchMapping("/{id}/approve")
    public TransactionRecord approve(@PathVariable Long id) {

        TransactionRecord t = repo.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Transaction not found"));

        t.setApprovalStatus("APPROVED");

        return repo.save(t);
    }

    @PatchMapping("/{id}/reject")
    public TransactionRecord reject(@PathVariable Long id) {

        TransactionRecord t = repo.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Transaction not found"));

        t.setApprovalStatus("REJECTED");

        return repo.save(t);
    }


}