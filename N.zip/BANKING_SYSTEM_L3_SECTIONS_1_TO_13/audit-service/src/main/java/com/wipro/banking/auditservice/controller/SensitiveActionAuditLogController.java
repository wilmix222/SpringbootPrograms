package com.wipro.banking.auditservice.controller; import com.wipro.banking.auditservice.model.SensitiveActionAuditLog;

import com.wipro.banking.auditservice.repository.SensitiveActionAuditLogRepository;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/v1/audit-logs")

public class SensitiveActionAuditLogController
{ private final SensitiveActionAuditLogRepository repo;

    public SensitiveActionAuditLogController(SensitiveActionAuditLogRepository repo)
    {this.repo=repo;}

    @GetMapping
    public List<SensitiveActionAuditLog> getAll() {
        return repo.findAll();
    }

    @PostMapping
    public SensitiveActionAuditLog create(@RequestBody SensitiveActionAuditLog obj)
    {return repo.save(obj);}
   // @GetMapping
    //public List<SensitiveActionAuditLog> all(){return repo.findAll();}

    @GetMapping("/{id}") public SensitiveActionAuditLog get(@PathVariable Long id){return repo.findById(id).orElseThrow(()->
        new IllegalArgumentException("SensitiveActionAuditLog not found: "+id));} }
