package com.wipro.banking.auditservice.repository;

import com.wipro.banking.auditservice.model.SensitiveActionAuditLog;

import org.springframework.data.jpa.repository.JpaRepository;
public interface SensitiveActionAuditLogRepository extends JpaRepository<SensitiveActionAuditLog,Long>


{



}
