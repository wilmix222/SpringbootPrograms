package com.wipro.banking.customerservice.controller;
import com.wipro.banking.customerservice.model.Customer;
import com.wipro.banking.customerservice.repository.CustomerRepository;
import com.wipro.banking.customerservice.service.CustomerServiceImpl;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/v1/customers")
public class CustomerController{
    private final CustomerServiceImpl service;
    private  CustomerRepository repository;
    public CustomerController(CustomerServiceImpl service){this.service=service;}
    @PostMapping
    public Customer create(@RequestBody Customer c){return service.onboard(c);}
    @GetMapping("/{id}") public Customer get(@PathVariable Long id){return service.get(id);}
    @GetMapping public List<Customer> all(){return service.all();}
    @PatchMapping("/{id}/kyc")
    public Customer kyc(@PathVariable Long id,@RequestParam String status)
    {return service.updateKyc(id,status);}

    @PutMapping("/{id}")
    public Customer update(
            @PathVariable Long id,
            @RequestBody Customer customer) {

        Customer existing =
                repository.findById(id)
                        .orElseThrow(() ->
                                new IllegalArgumentException("Customer not found"));

        existing.setFullName(customer.getFullName());
        existing.setEmail(customer.getEmail());
        existing.setPhone(customer.getPhone());
        existing.setAddress(customer.getAddress());
        existing.setKycStatus(customer.getKycStatus());

        return repository.save(existing);
    }



}
