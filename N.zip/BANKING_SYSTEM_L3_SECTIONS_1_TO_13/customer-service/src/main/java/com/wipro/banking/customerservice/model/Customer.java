package com.wipro.banking.customerservice.model;
import javax.persistence.*; import javax.validation.constraints.*;
@Entity
@Table(name="CUSTOMERS", uniqueConstraints=@UniqueConstraint(columnNames="email"))
public class Customer{

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @NotBlank
    private String fullName;
    @Email
    @NotBlank
    private String email;
    private String phone;
    private String address;
    private String kycStatus="PENDING";
    private Integer riskScore=50;
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public String getFullName(){return fullName;}
    public void setFullName(String fullName){this.fullName=fullName;}
    public String getEmail(){return email;}
    public void setEmail(String email){this.email=email;}
    public String getPhone(){return phone;}
    public void setPhone(String phone){this.phone=phone;}
    public String getAddress(){return address;}
    public void setAddress(String address){this.address=address;}
    public String getKycStatus(){return kycStatus;}
    public void setKycStatus(String kycStatus){this.kycStatus=kycStatus;}
    public Integer getRiskScore(){return riskScore;}
    public void setRiskScore(Integer riskScore){this.riskScore=riskScore;}
}
