package com.wipro.banking.integrationservice.model;
import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;


@Entity
@Table(name="INTEGRATION_REQUESTS")

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class IntegrationRequest
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
    private String integrationType;
    private String providerName;

    private String requestPayload;

    private String responseStatus="SIMULATED";
    private java.time.LocalDateTime createdAt=java.time.LocalDateTime.now();
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}

}
