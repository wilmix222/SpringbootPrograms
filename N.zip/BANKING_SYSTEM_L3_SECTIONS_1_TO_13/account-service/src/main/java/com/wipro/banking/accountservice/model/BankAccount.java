package com.wipro.banking.accountservice.model;
import javax.persistence.*;
import java.math.BigDecimal;
@Entity
@Table(name="ACCOUNTS", uniqueConstraints=@UniqueConstraint(columnNames="accountNumber"))
public class BankAccount{ @Id @GeneratedValue(strategy=GenerationType.IDENTITY)

private Long id; private Long customerId;
private String accountNumber;
private String accountType="SAVINGS";
private BigDecimal balance=BigDecimal.ZERO;
private String status="ACTIVE";
public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public Long getCustomerId(){return customerId;}

    public void setCustomerId(Long customerId){this.customerId=customerId;}
    public String getAccountNumber(){return accountNumber;}
    public void setAccountNumber(String accountNumber){this.accountNumber=accountNumber;}
    public String getAccountType(){return accountType;}
    public void setAccountType(String accountType){this.accountType=accountType;}
    public BigDecimal getBalance(){return balance;}
    public void setBalance(BigDecimal balance){this.balance=balance;}
    public String getStatus(){return status;}
    public void setStatus(String status){this.status=status;}
}
