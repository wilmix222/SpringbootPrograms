package com.wipro.banking.accountservice.controller;


import com.wipro.banking.accountservice.model.BankAccount;
import com.wipro.banking.accountservice.service.AccountServiceImpl;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/v1/accounts")
@CrossOrigin(origins = "http://localhost:4200")
public class AccountController {

    private final AccountServiceImpl service;

    public AccountController(AccountServiceImpl service) {
        this.service = service;
    }

    @PostMapping
    public BankAccount create(@RequestBody BankAccount account) {
        return service.create(account);
    }

    @GetMapping
    public List<BankAccount> getAllAccounts() {
        return service.getAllAccounts();
    }

    @GetMapping("/{id}")
    public BankAccount get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping("/number/{no}")
    public BankAccount byNo(@PathVariable String no) {
        return service.byNumber(no);
    }

    @GetMapping("/customer/{customerId}")
    public List<BankAccount> byCustomer(@PathVariable Long customerId) {
        return service.byCustomer(customerId);
    }

    @PostMapping("/{no}/credit")
    public BankAccount credit(
            @PathVariable String no,
            @RequestParam BigDecimal amount) {

        return service.credit(no, amount);
    }

    @PostMapping("/{no}/debit")
    public BankAccount debit(
            @PathVariable String no,
            @RequestParam BigDecimal amount) {

        return service.debit(no, amount);
    }

    @PatchMapping("/{no}/freeze")
    public BankAccount freeze(@PathVariable String no) {
        return service.freeze(no);
    }
}