package com.wipro.banking.accountservice.service;

import com.wipro.banking.accountservice.model.BankAccount;

import com.wipro.banking.accountservice.repository.AccountRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.*;
@Service
public class AccountServiceImpl{
    private final AccountRepository repo;
    public AccountServiceImpl(AccountRepository repo){this.repo=repo;}


    public BankAccount create(BankAccount a)
    { if(a.getAccountNumber()==null||a.getAccountNumber().isBlank())
        a.setAccountNumber("AC"+System.currentTimeMillis());

        return repo.save(a);}



    public List<BankAccount> getAllAccounts() {

        return repo.findAll();
    }


    public BankAccount byNumber(String n)
    {return repo.findByAccountNumber(n).orElseThrow(()->new IllegalArgumentException("Account not found: "+n));}

    public BankAccount get(Long id){return repo.findById(id).orElseThrow(()->new IllegalArgumentException("Account not found: "+id));}
    public List<BankAccount> byCustomer(Long c){return repo.findByCustomerId(c);}
    public BankAccount credit(String n,BigDecimal amt){BankAccount a=byNumber(n);
        a.setBalance(a.getBalance().add(amt)); return repo.save(a);}
    public BankAccount debit(String n,BigDecimal amt){BankAccount a=byNumber(n);
        if(a.getBalance().compareTo(amt)<0)
            throw new IllegalArgumentException("Insufficient balance");
        a.setBalance(a.getBalance().subtract(amt));
        return repo.save(a);}
    public BankAccount freeze(String n){BankAccount a=byNumber(n);
        a.setStatus("FROZEN"); return repo.save(a);}


}
