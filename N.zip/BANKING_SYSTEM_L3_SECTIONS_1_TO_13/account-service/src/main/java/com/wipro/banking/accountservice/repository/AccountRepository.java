package com.wipro.banking.accountservice.repository;
import com.wipro.banking.accountservice.model.BankAccount;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface AccountRepository extends JpaRepository<BankAccount,Long>
{ Optional<BankAccount> findByAccountNumber(String accountNumber);
    List<BankAccount> findByCustomerId(Long customerId);

}
