package com.wipro.banking.reportingservice.model;
import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name="REPORT_SNAPSHOTS")

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class ReportSnapshot
{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
    private String reportType;
    private String summary;
    private java.time.LocalDateTime generatedAt=java.time.LocalDateTime.now();
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}

}
