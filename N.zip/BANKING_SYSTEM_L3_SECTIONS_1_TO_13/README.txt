SPRING BOOT L3 - BANKING SYSTEM COMPLETE PROJECT (SECTIONS 1 TO 13)

This is a single Maven multi-module Spring Boot project for the Banking System assignment.

Included modules:
- auth-service: authentication, roles, BCrypt password hashing
- customer-service: customer onboarding, KYC status, risk score
- account-service: savings/current account operations, debit/credit/freeze
- transaction-service: transfer record and history API
- loan-service: loan application workflow API
- card-service: card record API
- notification-service: notification log API
- audit-service: sensitive action audit logs
- integration-service: payment/KYC/AML/credit scoring integration boundary
- reporting-service: reporting and analytics snapshot API

Build:
mvn clean test
mvn clean package

Run example:
mvn spring-boot:run -pl auth-service
mvn spring-boot:run -pl customer-service

See docs/sections for Section 1 to Section 13 documentation.
Import postman/Banking_System_L3_Complete.postman_collection.json into Postman for API validation.
