package com.wipro.banking.notificationservice.model;
import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name="NOTIFICATION_LOGS")

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class NotificationLog{

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public Long id;
    private String recipient;
    private String channel="EMAIL";
    private String message;
    private java.time.LocalDateTime sentAt=java.time.LocalDateTime.now();
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}

}
